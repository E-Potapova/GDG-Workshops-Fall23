using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // negative: moving left, positive: moving right
    [SerializeField] private float speed = 0;
    
    //[SerializeField] private bool movingLeft = true;
    [SerializeField] private Transform checkHeadWallCollision;
    private float checkHeadWallCollisionRadius = 0.05f;
    [SerializeField] private LayerMask thisIsGround;
    private bool hitWall = false;

    // Update is called once per frame
    void Update()
    {
        hitWall = Physics2D.OverlapCircle(checkHeadWallCollision.position, checkHeadWallCollisionRadius, thisIsGround);
        if (hitWall)
        {
            Flip();
        }
    }

    private void FixedUpdate()
    {
        transform.position = new Vector3(
            transform.position.x + speed,
            transform.position.y,
            transform.position.z
            );
    }

    private void Flip()
    {
        Vector3 currScale = gameObject.transform.localScale;
        currScale.x *= -1;
        gameObject.transform.localScale = currScale;
        speed *= -1;
    }
}
