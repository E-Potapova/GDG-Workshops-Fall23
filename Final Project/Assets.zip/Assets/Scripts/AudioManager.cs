using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [SerializeField] private Sound[] sounds;
    private Dictionary<string, Sound> audioNameToSound;

    public static AudioManager singleton;

    private void OnEnable()
    {
        if (singleton == null)
        {
            singleton = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        audioNameToSound = new Dictionary<string, Sound>();
        foreach (Sound sound in sounds)
        {
            if (!sound.source)
            {
                sound.source = gameObject.AddComponent<AudioSource>();
            }
            audioNameToSound.Add(sound.name, sound);
        }
    }

    public void Play(string name)
    {
        Sound sound = audioNameToSound[name];
        sound.source.PlayOneShot(sound.clip, sound.volume);
    }
}
