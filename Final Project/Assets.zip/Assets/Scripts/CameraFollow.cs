using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    // that object that the camera is going to follow
    [SerializeField] Transform target;
    // the bounds that the camera will not go past
    [SerializeField] float minX;
    [SerializeField] float minY;
    [SerializeField] float maxX;
    [SerializeField] float maxY;
    // even though this is a 2D game, all objects still
    // have a z-coordinate; we make it negative so
    // that the camera is 'behind' all of our game objects
    // so that everything is visible to our camera
    [SerializeField] float cameraZ = -10;

    // Update is called once per frame
    void Update()
    {
        // if our target doesn't exist anymore, we don't do anything
        if (!target) return;
        // we can't modify target.position x/y coordinates
        // directly, so we save a copy of it, modify the copy,
        // and then set the target.position to the modified copy
        Vector3 targetPos = target.position;
        targetPos.x = Mathf.Clamp(targetPos.x, minX, maxX);
        targetPos.y = Mathf.Clamp(targetPos.y, minY, maxY);
        targetPos.z = cameraZ;
        gameObject.transform.position = targetPos;
    }
}
