using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// we need to import to move between scenes
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // the callback used by the "Start Game" button
    public void OnStartGame()
    {
        // LoadScene() moves to the scene specified by either
        // its name or index in the Build Settings.
        // in our case we are loading the scene that
        // comes sequentially after this one (the main menu),
        // as specified in the Build Settings
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    // the callback used by the "Quit" button
    public void OnQuit()
    {
        // closes the application; only does something when
        // you Build and Run your game (doesn't do anything
        // when you Play the game in the Editor)
        Application.Quit();
    }
}
