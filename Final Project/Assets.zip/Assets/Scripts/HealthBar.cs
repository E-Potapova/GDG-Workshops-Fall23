using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBar : MonoBehaviour
{
    // this is called by Unity when the object becomes Enabled,
    // which happens when you enter Play mode in the editor
    private void OnEnable()
    {
        EventManager.OnHealthChange += SetHealth;
    }

    // the opposite of OnEnable, is called when leaving Play mode or
    // whenever the object is destroyed
    private void OnDisable()
    {
        EventManager.OnHealthChange -= SetHealth;
    }

    // a listener (callback) function for the OnHealthChange event
    // where 'health' is provided by the invocation done by the Player.
    // it loops through all child GameObjects (Hearts) that this gameObject
    // (HealthBar) has and activates them one at a time depending on
    // their index/location
    private void SetHealth(int health)
    {
        // child information is saved in the transform of this object (HealthBar).
        // childCount is the amount of children this object have; we loop over it
        for (int i = 0; i < gameObject.transform.childCount; i++)
        {
            // activate the number of Hearts that is equal to the 'health'
            // parameter that was passed to us.
            // for example if 'health'=3, then Hearts with index 0,1,2 are activated
            // which means they are visible on-screen.
            if (i < health)
            {
                gameObject.transform.GetChild(i).gameObject.SetActive(true);
            }
            // the rest of the hearts we deactivate, so that they are not visible
            else
            {
                gameObject.transform.GetChild(i).gameObject.SetActive(false);
            }
        }
    }
}
