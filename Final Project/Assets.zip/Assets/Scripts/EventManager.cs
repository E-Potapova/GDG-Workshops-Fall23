using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// this is a script that just exists within our project
// without being attached to a GameObject, which
// is why it is static
public static class EventManager
{
    // a delegate is essentially a variable that has a
    // function as its type
    public delegate void HealthChangeEvent(int health);
    // need to make a public static instance of that
    // delegate type so that scripts outside of
    // this one can refer to these events
    public static HealthChangeEvent OnHealthChange;

    public delegate void GameOverEvent();
    public static GameOverEvent OnGameOver;

    public delegate void LevelFinishedEvent();
    public static LevelFinishedEvent OnLevelFinished;
}
