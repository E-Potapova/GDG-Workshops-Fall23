using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// this script keeps track of the state of the game and
// updates things accordingly
public class GameManager : MonoBehaviour
{
    // the text objects that are displayed when the game is over
    // and when the level is complete, which relate to
    // the state of the game (game over, game win)
    [SerializeField] private GameObject textLevelFinished;
    [SerializeField] private GameObject textGameOver;

    // this is the variable that keeps track if we already have an instance
    // of this script/object or not.
    // public so that we can reference the GameManager from any other
    // script.
    // static means that there is only one of these variables across all
    // instances of this script.
    public static GameManager singleton;

    // called by Unity when this script is first started
    private void OnEnable()
    {
        // if our singleton isnt defined, then this script is
        // going to be our singleton
        if (singleton == null)
        {
            // save this instance as the singleton
            singleton = this;
            // dont destroy the object this script is attached to
            // when moving between scenes
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            // if we already have a singleton and
            // we accidentally have multiple instances of
            // the script, then we destroy the extra one
            Destroy(gameObject);
            return;
        }

        // subscribe the listener (callback) functions to the events
        EventManager.OnLevelFinished += LevelFinished;
        EventManager.OnGameOver += GameOver;
    }

    // called by Unity when the object is destroyed or disabled
    private void OnDisable()
    {
        // unsubscribe from the events
        EventManager.OnLevelFinished -= LevelFinished;
        EventManager.OnGameOver -= GameOver;
    }

    // the listener (callback) function that is called when the
    // OnLevelFinished event is invoked.
    private void LevelFinished()
    {
        // pause the game
        Time.timeScale = 0;
        // show the text on screen
        textLevelFinished.SetActive(true);
    }

    // the listener (callback) function that is called when the
    // OnGameOver event is invoked.
    private void GameOver()
    {
        // pause the game
        Time.timeScale = 0;
        // show the text on screen
        textGameOver.SetActive(true);
    }
}
