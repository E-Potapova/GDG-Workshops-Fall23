using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// this is a class that is used like a custom type
// rather than an object that does something.
// we make it 'Serializable' so that we can use objects
// of this type in fields in the Inspector
[System.Serializable]
// this class has all info regarding a sound clip
public class Sound
{
    // the name of our sound clip, what we use to play sounds
    public string name;
    // the object that will be playing this sound,
    // refers to the Audio Source component attached to that object
    public AudioSource source;
    // the actual sound file, like .wav or .mp3
    public AudioClip clip;
    // the volume, 0 for 0% and 1 for 100%
    [Range(0f, 1f)] public float volume;
}
