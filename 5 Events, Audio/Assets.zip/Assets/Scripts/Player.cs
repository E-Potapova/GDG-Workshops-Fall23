using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    #region Movement Fields
    // SerializeField means we can view and edit this value through the Inspector.
    // speed is how fast our Player moves left and right.
    // 'float' is a type saying it is a floating-point number, AKA decimal
    [SerializeField] float speed = 5.0f;
    // jumpForce is how fast our Player moves up when jumping.
    [SerializeField] float jumpForce = 5.0f;
    // canJump is used to keep track is the Player is allowed to jump or not.
    // by default 'true' since the Player starts on the ground.
    // 'bool' is a type that can only be 'true' or 'false'.
    bool canJump = true;
    // this is where we will save the Rigidbody2D Component (has type 'Rigidbody2D').
    // need this to affect Player physics (like moving and jumping).
    // declaring rb2D so that we can use it throughout our Player class,
    // but setting it later in our Start() method
    Rigidbody2D rb2D;
    #endregion

    #region Animation Fields
    // the variable where we save a reference to the Animator component.
    // we need this to be able to change the booleans or Conditions of our animator.
    // changing the booleans allows for our animations to change properly
    Animator animator;
    // this is used to determine the direction is/has been moving.
    // when spawned, the Player is facing to the right by default
    // (based on how the sprites were drawn).
    bool movingRight = true;
    #endregion

    #region Timer Fields
    // how long our timer is; how long the power-up will lasts, in seconds.
    // I made it Serialized so that we can edit this through our Inspector tab.
    [SerializeField] float powerTimerLength = 5.0f;
    // says if the Player is currently powered-up or not. false (not) by default.
    bool isPoweredUp = false;
    // a variable that will house the timestamp of when our timer is complete.
    // currently set to 0 seconds, and will be updated once we picup a power.
    float powerEndTime = 0.0f;
    #endregion

    // declare and initialize a health amount for our Player.
    // I set it to an integer type because I want any damage source to
    // deal 1 damage to my Player, but you can design it how you'd like
    int health = 5;
    

    // Start is called when the Player is first created in the world
    void Start()
    {
        // get the Rigibody2D component and save it into our variable.
        // we don't specify type here since we did so in line 15.
        // 'gameObject' refers to the GameObject that the script is
        // attached to (so the Player GameObject)
        rb2D = gameObject.GetComponent<Rigidbody2D>();
        // get the Rigibody2D component and save it into our variable that we declared on line 25.
        animator = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        // GetAxisRaw checks if the user is pressing Horizontal buttons as defined on the Horizontal Axis.
        // (check all Axes in Edit -> Project Settings -> Input Manager -> Axes)
        // returns -1 if pressing left, 0 if not pressing anything, and 1 if pressing right.
        float direction = Input.GetAxisRaw("Horizontal");
        // update the velocity of the Player based on the direction and speed.
        // the Y-value of the velocity doesn't change since moving left/right doesn't
        // affect how much we move up/down.
        // the '.' notation means we are accessing a property specifically of our rb2D variable
        rb2D.velocity = new Vector2(direction * speed, rb2D.velocity.y);
        // we check what value our 'direction' variable is set to.
        // if it is not 0, then we are moving left or right; if it is 0, we are not moving.
        if (direction != 0)
        {
            // we are moving, so set the 'isRunning' boolean defined in our Animator panel to true.
            animator.SetBool("isRunning", true);
            if (direction < 0 && movingRight)
            {
                // since movingRight == true, that means we have been moving to the right.
                // since direction<0, that means we now want to move left.
                // so, flip our character
                Flip();
            }
            else if (direction > 0 && !movingRight)
            {
                // since movingRight == false, that means we have been moving to the left.
                // since direction>0, that means we now want to move right.
                // so, flip our character
                Flip();
            }
        }
        else
        {
            // 'direction' is 0 so we are not moving.
            // set the 'isRunning' boolean defined in our Animator panel to false.
            animator.SetBool("isRunning", false);
        }

        // first check if we canJump; if it is set to false, we ignore the rest.
        // if it is true, check if the user pressed a Vertical up button (to jump).
        // we check if it is > 0 since 1 means the user pressed up, and -1 means they pressed down.
        if (canJump && Input.GetAxisRaw("Vertical") > 0)
        {
            // update the velocity of the Player based on our jumpForce, the Y-value.
            // the X-value doesn't change since jumping doesn't affect horizontal movement.
            rb2D.velocity = new Vector2(rb2D.velocity.x, jumpForce);
            // we don't want the Player to jump anytime we press the Jump button.
            // for example, the Player shouldn't jump again when already in the air.
            canJump = false;
            // since we are jumping, we update our animator.
            // set the 'isJumping' boolean defined in our Animator panel to true.
            animator.SetBool("isJumping", true);
        }

        // if the Player is powered up, then the timer is active.
        // check if the timer is done now.
        if (isPoweredUp) PowerUpTimerCheck();
    }

    // built-in function provided by Unity.
    // this is called for us whenever the Player hits something that has a Collider component.
    // 'collision' is all information stored about the impact.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // 'collision.gameObject' gives us the GameObject that the Player has collided with.
        // '.tag' gives us the Tag of the object, as seen in the Inspector below the object name.
        // we check what this tag is to check if we are colliding with a type of object.

        // check if we collided with a GameObject with Tag 'Ground'
        if (collision.gameObject.tag == "Ground") 
        {
            // inside here, we know the Player has touched Ground,
            // so we tell the Player that thay are allowed to jump again.
            canJump = true;
            // since we are not jumping anymore, we set the 'isJumping' boolean to false.
            animator.SetBool("isJumping", false);
        }
    }

    // built-in function provided by Unity.
    // this is called for us whenever the Player hits something that has a Collider component,
    // but has 'Is Trigger' set to true.
    // 'collision' is all information stored about the trigger.
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // what's the Tag of the GameObject we're colliding with?
        if (collision.gameObject.tag == "Finish")
        {
            // Debug.Log() shows our message in the Console tab, can be
            // found next to the Project tab
            Debug.Log("Goal reached!");
        }
        else if (collision.gameObject.tag == "Damage")
        {
            // is this is any Damage source, decrease our Player's health
            health--;
            Debug.Log("Health: " + health);
            // if the Player's health is below 0, we want the Player to die,
            // easiest way to do that is to delete or  get rid of the Player GameObject.
            // you can see Destroy() gets rid of the GameObject in the Hierarchy tab
            if (health < 1)
            {
                Destroy(gameObject);
                Debug.Log("You died :(");
            }
        }
        else if (collision.gameObject.tag == "Pickup_Power")
        {
            // once we 'collide' with the pickup, we want to destroy it.
            Destroy(collision.gameObject);
            // set the timer for how long our power-up lasts.
            PowerUpTimerCheck();
        }
    }

    // this function either sets the timer if the Player is not powered-up,
    // or checks if the timer is done if the Player is currently powered-up.
    private void PowerUpTimerCheck()
    {
        // check if we are NOT powered-up.
        // same as 'if (!isPoweredUp)'
        if (isPoweredUp == false)
        {
            // say that we are now powered-up
            isPoweredUp = true;
            // set the timer by getting the current time with Time.time
            // and add the length of our power timer.
            powerEndTime = Time.time + powerTimerLength;
            // activate the effect of our power-up, which in this case
            // doubles the movement speed of the Player.
            // same as speed = speed * 2;
            speed *= 2;
        }
        else
        {
            // check if the timer is done by checking if the current time
            // is past the saved timer timestamp
            if (Time.time > powerEndTime)
            {
                // deactivate the power-up effect, so halve the movement speed.
                // same as speed = speed / 2;
                speed /= 2;
                // say that we are not powered-up anymore.
                isPoweredUp = false;
            }
        }
    }


    // A function we have defined that flips our Player when it is called.
    // it is private so that functions/scripts/objects outside of this one can't see
    // this function (we don't want random object to flip our Player!).
    // has a return type of 'void' since it just does something without computing
    // and returning a value.
    private void Flip()
    {
        // we can't modify transform.localScale directly, so we first save
        // a copy, then modify the copy, and then set the localScale to the copy.
        Vector3 currScale = gameObject.transform.localScale;
        // flipping something horizontally is the same as multiplying by a negative scale.
        // this is shorthand for currScale.x = currScale.x * -1;
        currScale.x *= -1;
        gameObject.transform.localScale = currScale;

        // if we have been moving to the right, we are now moving left.
        // and vice versa.
        // easy way to do this is to set the boolean equal to the opposite of what it is!
        movingRight = !movingRight;
    }
}
