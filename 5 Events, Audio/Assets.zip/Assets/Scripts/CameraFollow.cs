using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField] Transform target;
    [SerializeField] float minX;
    [SerializeField] float maxX;
    [SerializeField] float minY;
    [SerializeField] float maxY;
    [SerializeField] float cameraZ = -10;

    // Update is called once per frame
    void Update()
    {
        if (!target) return;
        Vector3 targetPos = target.position;
        targetPos.x = Mathf.Clamp(targetPos.x, minX, maxX);
        targetPos.y = Mathf.Clamp(targetPos.y, minY, maxY);
        targetPos.z = cameraZ;
        gameObject.transform.position = targetPos;
    }
}
