These 3 SFX clips are taken from "The Essential Retro Video Game Sound Effects Collection [512 sounds]" by Juhani Junkala, found on opengameart.org: 
https://opengameart.org/content/512-sound-effects-8-bit-style

SFX_Player_Damage.wav is originally
/General Sounds/Impacts/sfx_sounds_impact1.wav

SFX_Player_Jump.wav is originally
/Movement/Jumping and Landing/sfx_movement_jump16.wav

SFX_Player_Land.wav is originally
/Movement/Jumping and Landing/sfx_movement_jump16_landing.wav